# electron-integration

Example of successful SDK integration, starting from the [Electron Quick Start demo App](https://github.com/electron/electron-quick-start).

## To Use

```bash
# Install dependencies
npm install
# Run the app
npm start
```