export default{
  END_DL: "Termina analisi e scarica CSV",
  SHARE_URL: "Condividi questo URL di invito con lo studente",
  WAITING_CLIENT: "In attesa di collegamento dello studente...",
  LINK_COPIED: "Link copiato con successo",
  SHARE_BTN: "Copia URL invito",
  CREATE_ROOM: "Crea video-call",
  USERN_NAME: "Nome studente",
  CONTINUE:"Continua",
  ALLOW_CAMERA: "Chiedo il permesso di accedere alla camera",
  CAMERA_DENIED: "Impossibile accedere alla camera, permesso negato",
  ENTER: "Entra"
};
