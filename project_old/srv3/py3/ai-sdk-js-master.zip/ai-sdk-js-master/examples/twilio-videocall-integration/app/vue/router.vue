<template>
  <div class="h-full bg-gray-200">
    <router-view></router-view>
  </div>
</template>

<script>
  export default {
    name: "router.vue"
  }
</script>

<style lang="scss" scoped>

</style>